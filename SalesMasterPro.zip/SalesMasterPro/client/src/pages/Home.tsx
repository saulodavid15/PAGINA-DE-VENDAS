import React, { useEffect } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Introduction from '@/components/Introduction';
import ProofSection from '@/components/ProofSection';
import PainPoints from '@/components/PainPoints';
import CourseContent from '@/components/CourseContent';
import PurchaseSection from '@/components/PurchaseSection';
import FAQ from '@/components/FAQ';
import CallToAction from '@/components/CallToAction';
import Footer from '@/components/Footer';
import StickyNavbar from '@/components/StickyNavbar';
import FloatingCTA from '@/components/FloatingCTA';
import Testimonials from '@/components/Testimonials';
import GovtProofSection from '@/components/GovtProofSection';
import RealResultsSection from '@/components/RealResultsSection';

const Home: React.FC = () => {
  // Efeito para animação de fade-in nos elementos
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 } // Elemento aparece quando 10% dele está visível
    );

    // Seleciona todos os elementos com a classe fade-in
    const fadeElements = document.querySelectorAll('.fade-in');
    fadeElements.forEach((element) => {
      observer.observe(element);
    });

    return () => {
      fadeElements.forEach((element) => {
        observer.unobserve(element);
      });
    };
  }, []);

  return (
    <div className="relative">
      <StickyNavbar />
      <div id="hero">
        <Header />
        <Hero />
      </div>
      <div id="beneficios" className="fade-in">
        <Introduction />
      </div>
      <div className="fade-in">
        <ProofSection />
      </div>
      <div className="fade-in">
        <GovtProofSection />
      </div>
      <div className="fade-in">
        <RealResultsSection />
      </div>
      <div className="fade-in">
        <PainPoints />
      </div>
      <div id="conteudo" className="fade-in">
        <CourseContent />
      </div>
      <div className="fade-in">
        <Testimonials />
      </div>
      <div id="comprar-agora" className="fade-in">
        <PurchaseSection />
      </div>
      <div id="perguntas" className="fade-in">
        <FAQ />
      </div>
      <div className="fade-in">
        <CallToAction />
      </div>
      <Footer />
      <FloatingCTA />
    </div>
  );
};

export default Home;
