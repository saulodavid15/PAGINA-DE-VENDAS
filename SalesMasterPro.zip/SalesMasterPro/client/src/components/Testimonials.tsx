import React, { useState } from 'react';
import { useMobile } from '@/hooks/use-mobile';

interface Testimonial {
  name: string;
  role: string;
  content: string;
  image: string;
  stars: number;
}

const Testimonials: React.FC = () => {
  const isMobile = useMobile();
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  
  const testimonials: Testimonial[] = [
    {
      name: "Carlos Silva",
      role: "Proprietário de Papelaria",
      content: "Depois de fazer o curso, consegui fechar meu primeiro contrato com uma escola municipal. O processo foi muito mais simples do que eu imaginava e agora tenho um cliente que faz pedidos mensais!",
      image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
      stars: 5
    },
    {
      name: "Ana Rodrigues",
      role: "ME Fornecedora de Alimentos",
      content: "Já tentava entrar no mercado governamental há dois anos sem sucesso. Após aplicar as estratégias de email marketing do curso, consegui fechar três contratos em apenas um mês.",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
      stars: 5
    },
    {
      name: "Roberto Almeida",
      role: "MEI no setor de Serviços",
      content: "Os modelos prontos me economizaram horas de trabalho e pesquisa. Adaptei os documentos em minutos e enviei minhas primeiras propostas. Já estou no segundo contrato com a prefeitura.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
      stars: 4
    },
  ];

  // Função para navegar pelos testemunhos no modo mobile
  const changeTestimonial = (direction: 'next' | 'prev') => {
    if (direction === 'next') {
      setActiveTestimonial((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
    } else {
      setActiveTestimonial((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
    }
  };

  return (
    <section className="py-12 md:py-16 bg-gray-50 relative">
      {/* Onda decorativa superior */}
      <div className="absolute top-0 left-0 w-full overflow-hidden" style={{height: '50px', transform: 'translateY(-49px) rotate(180deg)'}}>
        <svg viewBox="0 0 500 150" preserveAspectRatio="none" style={{height: '100%', width: '100%'}}>
          <path d="M0.00,49.98 C149.99,150.00 349.20,-49.98 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style={{stroke: 'none', fill: '#fff'}}></path>
        </svg>
      </div>
      
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-primary text-center mb-8 md:mb-12 animate-fade-in-up text-2xl md:text-3xl">O Que Nossos Alunos Estão Dizendo</h2>
        
        {/* Versão desktop: grid de depoimentos */}
        {!isMobile && (
          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index}
                className="bg-white rounded-lg shadow-lg p-4 md:p-6 relative transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl animate-fade-in-up" 
                style={{animationDelay: `${0.2 * index}s`}}
              >
                <div className="absolute -top-4 md:-top-5 right-4 md:right-5 bg-accent text-white rounded-full p-2 shadow-md">
                  <div className="flex">
                    {Array.from({length: 5}).map((_, i) => (
                      <i 
                        key={i} 
                        className={`fas fa-star ${i < testimonial.stars ? 'text-yellow-300' : 'text-gray-300'} text-xs md:text-sm mx-0.5`}
                      ></i>
                    ))}
                  </div>
                </div>
                
                <div className="flex items-center mb-3 md:mb-4">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name} 
                    className="w-12 h-12 md:w-16 md:h-16 rounded-full mr-3 md:mr-4 border-2 border-primary object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                  <div>
                    <h4 className="font-bold text-gray-800 text-sm md:text-base">{testimonial.name}</h4>
                    <p className="text-xs md:text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
                
                <blockquote className="text-gray-700 italic relative text-sm md:text-base">
                  <i className="fas fa-quote-left absolute -top-3 -left-1 md:-top-4 md:-left-2 text-gray-200 text-3xl md:text-4xl opacity-50"></i>
                  <p className="relative z-10">{testimonial.content}</p>
                </blockquote>
              </div>
            ))}
          </div>
        )}
        
        {/* Versão mobile: slider com navegação */}
        {isMobile && (
          <div className="relative px-2">
            <div 
              className="bg-white rounded-lg shadow-lg p-4 relative animate-fade-in-up" 
              style={{animationDelay: '0.2s'}}
            >
              <div className="absolute -top-4 right-4 bg-accent text-white rounded-full p-2 shadow-md">
                <div className="flex">
                  {Array.from({length: 5}).map((_, i) => (
                    <i 
                      key={i} 
                      className={`fas fa-star ${i < testimonials[activeTestimonial].stars ? 'text-yellow-300' : 'text-gray-300'} text-xs mx-0.5`}
                    ></i>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center mb-3">
                <img 
                  src={testimonials[activeTestimonial].image} 
                  alt={testimonials[activeTestimonial].name} 
                  className="w-12 h-12 rounded-full mr-3 border-2 border-primary object-cover"
                  loading="lazy"
                  decoding="async"
                />
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">{testimonials[activeTestimonial].name}</h4>
                  <p className="text-xs text-gray-600">{testimonials[activeTestimonial].role}</p>
                </div>
              </div>
              
              <blockquote className="text-gray-700 italic relative text-sm">
                <i className="fas fa-quote-left absolute -top-3 -left-1 text-gray-200 text-3xl opacity-50"></i>
                <p className="relative z-10">{testimonials[activeTestimonial].content}</p>
              </blockquote>
            </div>
            
            {/* Navegação do slider */}
            <div className="flex justify-between items-center mt-4">
              <button 
                onClick={() => changeTestimonial('prev')}
                className="bg-white shadow-md rounded-full p-2 focus:outline-none"
              >
                <i className="fas fa-chevron-left text-primary"></i>
              </button>
              
              <div className="flex space-x-1">
                {testimonials.map((_, index) => (
                  <span 
                    key={index} 
                    className={`block h-2 rounded-full ${index === activeTestimonial ? 'w-4 bg-accent' : 'w-2 bg-gray-300'} transition-all`}
                    onClick={() => setActiveTestimonial(index)}
                  ></span>
                ))}
              </div>
              
              <button 
                onClick={() => changeTestimonial('next')}
                className="bg-white shadow-md rounded-full p-2 focus:outline-none"
              >
                <i className="fas fa-chevron-right text-primary"></i>
              </button>
            </div>
          </div>
        )}
        
        <div className="text-center mt-8 md:mt-10 animate-fade-in-up" style={{animationDelay: '0.8s'}}>
          <a 
            href="#comprar-agora" 
            className="bg-accent hover:bg-opacity-90 text-white font-bold py-2 md:py-3 px-4 md:px-6 rounded-lg inline-block transition shadow-lg btn-hover-effect text-sm md:text-base"
            style={{backgroundColor: '#E67E22'}}
          >
            QUERO RESULTADOS COMO ESTES <i className="fas fa-arrow-right ml-2"></i>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;