import React from 'react';
import { Link } from 'wouter';

const courseModules = [
  {
    icon: "fas fa-book",
    title: "Como funciona a venda para o governo",
    description: "Entenda de forma simples e direta todo o processo de vendas para órgãos públicos, desmistificando cada etapa.",
    topics: [
      "Estrutura de compras governamentais",
      "Fluxo de pagamentos e prazos reais",
      "Por que o governo é um ótimo cliente"
    ]
  },
  {
    icon: "fas fa-list-check",
    title: "Tipos de compras públicas",
    description: "Descubra as diferentes modalidades e identifique quais são mais adequadas para o seu negócio.",
    topics: [
      "Dispensa de licitação (ideal para iniciantes)",
      "Compra direta e como aproveitá-la",
      "Licitações simplificadas para pequenos negócios"
    ]
  },
  {
    icon: "fas fa-file-alt",
    title: "Documentos exigidos e organização",
    description: "Lista completa dos documentos necessários e como prepará-los corretamente.",
    topics: [
      "Checklist de documentação básica",
      "Como organizar e manter tudo em dia",
      "Passo a passo para obter certidões exigidas"
    ]
  }
];

const courseModules2 = [
  {
    icon: "fas fa-search",
    title: "Como encontrar oportunidades",
    description: "Domine as ferramentas de busca e cadastro no portal de compras governamentais.",
    topics: [
      "Acesso e navegação no Portal de Compras",
      "Filtros essenciais para encontrar oportunidades",
      "Configuração de alertas automáticos"
    ]
  },
  {
    icon: "fas fa-envelope",
    title: "Domine o Email Marketing",
    description: "Aprenda a utilizar uma ferramenta gratuita para conseguir mais contratos com o governo.",
    topics: [
      "Como montar uma lista de contatos autorizada e legal",
      "Escreva emails persuasivos que geram respostas",
      "Crie campanhas automáticas de seguimento"
    ]
  },
  {
    icon: "fas fa-trophy",
    title: "Dicas de sucesso de quem já lucra",
    description: "Estratégias avançadas dos fornecedores que já faturam milhares por mês.",
    topics: [
      "Como formar preços competitivos e lucrativos",
      "Relacionamento com compradores públicos",
      "Estratégias para crescer como fornecedor"
    ]
  }
];

const CourseContent: React.FC = () => {
  return (
    <section className="py-14 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="font-heading text-center text-primary">O Que Você Vai Aprender</h2>
          <p className="text-center mb-10 text-gray-600">Conteúdo completo para você começar a vender para o governo em tempo recorde</p>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              {courseModules.map((module, index) => (
                <div key={index} className="mb-6 bg-white p-6 rounded-lg shadow-md">
                  <div className="flex items-center mb-3">
                    <div className="bg-primary text-white h-10 w-10 rounded-full flex items-center justify-center mr-3">
                      <i className={module.icon}></i>
                    </div>
                    <h3 className="font-bold text-xl">{module.title}</h3>
                  </div>
                  <p className="text-gray-600 mb-3">{module.description}</p>
                  <ul className="text-gray-700">
                    {module.topics.map((topic, topicIndex) => (
                      <li key={topicIndex} className={`${topicIndex < module.topics.length - 1 ? 'mb-2' : ''} flex items-start`}>
                        <i className="fas fa-check text-success mt-1 mr-2"></i>
                        <span>{topic}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            
            <div>
              {courseModules2.map((module, index) => (
                <div key={index} className={`mb-6 ${module.title === "Domine o Email Marketing" ? 'bg-secondary text-white' : 'bg-white'} p-6 rounded-lg shadow-md`}>
                  <div className="flex items-center mb-3">
                    <div className={`${module.title === "Domine o Email Marketing" ? 'bg-accent' : 'bg-primary'} text-white h-10 w-10 rounded-full flex items-center justify-center mr-3`}>
                      <i className={module.icon}></i>
                    </div>
                    <h3 className="font-bold text-xl">{module.title}</h3>
                  </div>
                  <p className={`${module.title === "Domine o Email Marketing" ? 'text-white' : 'text-gray-600'} mb-3`}>{module.description}</p>
                  <ul className={`${module.title === "Domine o Email Marketing" ? 'text-white' : 'text-gray-700'}`}>
                    {module.topics.map((topic, topicIndex) => (
                      <li key={topicIndex} className={`${topicIndex < module.topics.length - 1 ? 'mb-2' : ''} flex items-start`}>
                        <i className={`fas fa-check ${module.title === "Domine o Email Marketing" ? 'text-accent' : 'text-success'} mt-1 mr-2`}></i>
                        <span>{topic}</span>
                      </li>
                    ))}
                  </ul>
                  {module.title === "Domine o Email Marketing" && (
                    <div className="mt-3 bg-white text-primary p-3 rounded text-center font-bold">
                      100% GRATUITO E LEGAL
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-10 text-center">
            <Link href="#comprar-agora" className="bg-accent hover:bg-opacity-90 text-white font-bold py-4 px-8 rounded-lg inline-block text-xl transition shadow-lg transform hover:scale-105">
              QUERO TER ACESSO A TODO ESSE CONTEÚDO AGORA
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CourseContent;
