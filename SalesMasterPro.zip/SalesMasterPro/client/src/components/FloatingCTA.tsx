import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'wouter';
import { useMobile } from '@/hooks/use-mobile';

const FloatingCTA: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const isMobile = useMobile();
  
  // Utiliza useCallback para evitar redefinição da função em cada render
  const handleScroll = useCallback(() => {
    const scrollPosition = window.scrollY;
    const heroSection = document.getElementById('hero');
    const purchaseSection = document.getElementById('comprar-agora');
    
    if (!heroSection || !purchaseSection) return;
    
    const heroBottom = heroSection.offsetTop + heroSection.offsetHeight;
    const purchaseTop = purchaseSection.offsetTop;
    
    // Adiciona limites de segurança para evitar bugs de exibição
    const safeHeroBottom = Math.max(0, heroBottom);
    const safePurchaseTop = Math.max(safeHeroBottom + 100, purchaseTop);
    
    // Só mostrar quando o usuário tiver passado da seção Hero, mas não chegado à seção de compra
    const shouldBeVisible = scrollPosition > safeHeroBottom && scrollPosition < safePurchaseTop - 300;
    
    if (shouldBeVisible !== isVisible) {
      setIsVisible(shouldBeVisible);
    }
  }, [isVisible]);
  
  useEffect(() => {
    // Executa handleScroll uma vez na montagem para definir a visibilidade inicial
    handleScroll();
    
    // Adiciona event listener com debounce para melhor performance
    let scrollTimeout: number | null = null;
    
    const debouncedScroll = () => {
      if (scrollTimeout) {
        clearTimeout(scrollTimeout);
      }
      
      scrollTimeout = window.setTimeout(handleScroll, 50);
    };
    
    window.addEventListener('scroll', debouncedScroll);
    window.addEventListener('resize', debouncedScroll); // Adiciona listener para resize da janela
    
    return () => {
      window.removeEventListener('scroll', debouncedScroll);
      window.removeEventListener('resize', debouncedScroll);
      if (scrollTimeout) {
        clearTimeout(scrollTimeout);
      }
    };
  }, [handleScroll]); // Dependência necessária porque handleScroll pode mudar
  
  // Utiliza a sintaxe de transição para exibição/escondimento em vez de retornar null
  return (
    <div 
      className={`fixed ${isMobile ? 'bottom-4 right-4' : 'bottom-6 right-6'} z-50 transition-all duration-500 transform animate-bounce-slow ${isVisible ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'}`} 
      style={{ animation: isVisible ? 'bounce 3s infinite' : 'none' }}
      aria-hidden={!isVisible}
    >
      <div className="relative">
        {!isMobile && (
          <div className="absolute -top-12 right-0 bg-white text-secondary text-xs px-3 py-1 rounded-lg font-bold shadow-md whitespace-nowrap">
            A partir de R$ 67,90! <i className="fas fa-arrow-down ml-1 text-accent"></i>
          </div>
        )}
        
        <Link 
          href="#comprar-agora" 
          className={`bg-accent text-white font-bold ${isMobile ? 'py-2 px-4 text-sm' : 'py-3 px-6'} rounded-full shadow-lg hover:shadow-xl btn-hover-effect flex items-center`} 
          style={{backgroundColor: '#E67E22'}}
          aria-label={isMobile ? "Comprar agora" : "Garantir minha vaga"}
          onClick={(e) => {
            e.preventDefault();
            document.getElementById('comprar-agora')?.scrollIntoView({ behavior: 'smooth' });
          }}
          role="button"
        >
          {isMobile ? (
            <>
              <span className="mr-1">Comprar</span>
              <i className="fas fa-shopping-cart" aria-hidden="true"></i>
            </>
          ) : (
            <>
              <span className="mr-2">Garantir Minha Vaga</span>
              <i className="fas fa-crown" aria-hidden="true"></i>
            </>
          )}
        </Link>
      </div>
    </div>
  );
};

export default FloatingCTA;