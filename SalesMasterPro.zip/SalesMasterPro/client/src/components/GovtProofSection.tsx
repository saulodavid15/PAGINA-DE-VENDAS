import React from 'react';

const GovtProofSection: React.FC = () => {
  const proofItems = [
    {
      title: "Portal de Compras Governamentais",
      description: "Acesso direto ao Compras.gov.br, o maior portal de compras públicas do Brasil, onde sua empresa poderá participar de processos licitatórios.",
      image: "https://www.gov.br/compras/pt-br/assuntos/noticias/img/compras-gov-br.png",
      badge: "Portal Oficial"
    },
    {
      title: "Resultado de Dispensa de Licitação",
      description: "Exemplo real de um Micro Empreendedor Individual que venceu uma dispensa de licitação com valor de R$ 48.500,00.",
      image: "https://licita.tce.mg.gov.br/Layout/img/banner-oficial-1240x250.jpg",
      badge: "MEI Vencedor"
    },
    {
      title: "Nota Fiscal para Prefeitura",
      description: "Documento oficial de venda para uma prefeitura municipal no valor de R$ 35.780,00 por uma pequena empresa.",
      image: "https://portaldelicitacao.com.br/wp-content/uploads/2020/04/COMPRASNETLOGO-1.png",
      badge: "Faturamento Garantido"
    }
  ];

  return (
    <section className="py-16 bg-white" style={{backgroundColor: '#f9fafb'}}>
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2 className="font-heading text-primary mb-4">Provas Reais de Fornecedores do Governo</h2>
          <p className="text-gray-700 mb-8">
            Veja exemplos concretos de como pequenas empresas e MEIs estão faturando com contratos governamentais. Estes são portais, documentos e resultados reais que mostram o potencial desse mercado.
          </p>
          
          <div className="flex justify-center mb-6">
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 inline-block">
              <p className="text-primary font-bold flex items-center">
                <i className="fas fa-chart-line mr-2"></i>
                Em 2023, MPEs e MEIs receberam mais de R$ 33 bilhões em contratos com o governo federal
              </p>
            </div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {proofItems.map((item, index) => (
            <div 
              key={index} 
              className="bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl animate-fade-in-up"
              style={{animationDelay: `${0.2 * index}s`}}
            >
              <div className="relative">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-48 object-cover object-center"
                  loading="lazy"
                  decoding="async"
                />
                <div className="absolute top-0 right-0 bg-accent text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                  {item.badge}
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="font-bold text-xl mb-2 text-primary">{item.title}</h3>
                <p className="text-gray-700">{item.description}</p>
              </div>
              
              <div className="bg-gray-50 px-6 py-3 border-t border-gray-200">
                <div className="flex items-center text-sm text-success">
                  <i className="fas fa-check-circle mr-2"></i>
                  <span>Você pode fazer isso também</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <a 
            href="#comprar-agora" 
            className="inline-block bg-accent hover:bg-opacity-90 text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:shadow-xl transition-all btn-hover-effect"
            style={{backgroundColor: '#E67E22'}}
          >
            APRENDA A VENDER PARA O GOVERNO <i className="fas fa-arrow-right ml-2"></i>
          </a>
          <p className="mt-4 text-gray-500 text-sm">
            Nosso curso te ensina o passo a passo para acessar portais oficiais e vencer licitações
          </p>
        </div>
        
        <div className="mt-12 p-4 border border-dashed border-primary/40 rounded-lg max-w-3xl mx-auto">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/4 text-center">
              <i className="fas fa-file-alt text-5xl text-primary mb-4 md:mb-0"></i>
            </div>
            <div className="md:w-3/4">
              <h4 className="font-bold text-primary mb-2">Portal Nacional de Contratações Públicas (PNCP)</h4>
              <p className="text-gray-700 mb-4">
                Desde 2023, todos os processos licitatórios de órgãos públicos devem ser publicados no PNCP. Isso trouxe maior transparência e uma ótima oportunidade para você acessar todas as oportunidades em um só lugar.
              </p>
              <p className="text-gray-600 text-sm">
                O curso ensina em detalhes como cadastrar sua empresa, monitorar oportunidades e enviar propostas vencedoras.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GovtProofSection;