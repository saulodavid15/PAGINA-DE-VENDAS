import React from 'react';
import { Link } from 'wouter';

const Header: React.FC = () => {
  return (
    <header className="bg-primary text-white">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <h2 className="font-heading font-bold text-xl md:text-2xl">VendaMais</h2>
        <Link href="#comprar-agora" className="bg-accent hover:bg-opacity-90 px-4 py-2 rounded font-bold text-sm transition">
          COMPRAR AGORA
        </Link>
      </div>
    </header>
  );
};

export default Header;
