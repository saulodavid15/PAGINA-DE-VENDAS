import React, { useState } from 'react';
import { useMobile } from '@/hooks/use-mobile';

const faqItems = [
  {
    question: "Preciso ter CNPJ?",
    answer: "Sim, para vender para o governo é necessário ter um CNPJ ativo. A boa notícia é que mesmo um MEI (Microempreendedor Individual) pode participar da maioria das compras públicas, especialmente em dispensas de licitação e compras diretas."
  },
  {
    question: "Como funciona o email marketing gratuito do curso?",
    answer: "No módulo de email marketing, você aprenderá a utilizar uma ferramenta 100% gratuita e legal para se comunicar com compradores públicos. Ensinaremos desde a montagem da sua lista de contatos até a criação de campanhas automatizadas que geram resultados reais, sem nenhum custo para o seu negócio."
  },
  {
    question: "Quanto tempo para começar a vender?",
    answer: "Com os documentos e cadastros em dia, muitos alunos conseguem fazer sua primeira venda em 30 a 60 dias após o início do curso. Tudo depende da sua agilidade em aplicar as estratégias ensinadas e da disponibilidade de oportunidades compatíveis com o seu negócio. As técnicas de email marketing podem acelerar esse processo."
  },
  {
    question: "Como aplicar o conteúdo na prática?",
    answer: "O curso foi desenvolvido com foco na aplicação prática imediata. Cada aula é seguida por exercícios e tarefas que o guiam para a ação. Você receberá modelos prontos, checklists, e exemplos reais de documentos e propostas que funcionaram, além da ferramenta gratuita de email marketing para aplicar no seu dia a dia."
  },
  {
    question: "Preciso de contador?",
    answer: "Embora seja recomendável ter um contador para auxiliar com questões fiscais, não é um impedimento para começar. No curso, você aprenderá o que pode fazer por conta própria e quando precisará de ajuda profissional. Muitos MEIs conseguem gerenciar boa parte do processo sozinhos."
  },
  {
    question: "E se eu não gostar do curso?",
    answer: "Oferecemos garantia de 7 dias. Se você não ficar satisfeito com o conteúdo por qualquer motivo, basta solicitar o reembolso dentro deste prazo e devolveremos 100% do seu investimento, sem perguntas."
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState(0);
  const isMobile = useMobile();

  const toggleFaq = (index: number) => {
    if (openIndex === index) {
      return; // Keep first FAQ always open as per the design
    }
    setOpenIndex(index);
  };

  return (
    <section className="py-10 md:py-14 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-heading mb-4 md:mb-6 text-center text-primary text-2xl md:text-3xl">Perguntas Frequentes</h2>
          <p className="text-center mb-6 md:mb-10 text-sm md:text-base">Respostas para as dúvidas mais comuns sobre o curso e o processo de vendas para o governo</p>
          
          <div className="space-y-3 md:space-y-4" id="faq-accordion">
            {faqItems.map((item, index) => (
              <div key={index} className={`border ${index === 1 || index === 3 ? 'border-accent bg-accent bg-opacity-5' : 'border-gray-200'} rounded-lg overflow-hidden shadow-sm`}>
                <button 
                  className={`faq-button w-full text-left p-3 md:p-5 ${index === 1 || index === 3 ? 'bg-accent bg-opacity-10 hover:bg-opacity-15' : 'bg-gray-50 hover:bg-gray-100'} transition flex justify-between items-center focus:outline-none focus:ring-2 focus:ring-primary/30`}
                  onClick={() => toggleFaq(index)}
                  aria-expanded={openIndex === index}
                  aria-controls={`faq-answer-${index}`}
                  id={`faq-question-${index}`}
                >
                  <span className="font-bold text-sm md:text-base pr-2">{item.question}</span>
                  <i 
                    className={`${index === 1 || index === 3 ? 'fas fa-lightbulb text-accent' : 'fas fa-chevron-down text-gray-500'} transform transition-transform ${openIndex === index ? 'rotate-180' : ''} text-sm md:text-base flex-shrink-0`}
                    aria-hidden="true"
                  ></i>
                </button>
                <div 
                  id={`faq-answer-${index}`}
                  className={`faq-answer p-3 md:p-5 border-t ${index === 1 || index === 3 ? 'border-accent border-opacity-20' : 'border-gray-200'} bg-white ${openIndex !== index ? 'hidden' : ''}`}
                  aria-labelledby={`faq-question-${index}`}
                  role="region"
                >
                  <p className="text-sm md:text-base">{item.answer}</p>
                  {(index === 1 || index === 3) && (
                    <div className="mt-2 md:mt-3 p-2 bg-secondary bg-opacity-10 border-l-4 border-secondary rounded">
                      <p className="font-bold text-secondary text-xs md:text-sm">Aplicação prática garantida!</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          {/* Botão de esclarecimento de mais dúvidas para versão mobile */}
          {isMobile && (
            <div className="mt-6 text-center">
              <a 
                href="#comprar-agora" 
                className="inline-block bg-accent/90 text-white font-medium py-2 px-4 rounded-lg text-sm shadow-md btn-hover-effect"
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('comprar-agora')?.scrollIntoView({ behavior: 'smooth' });
                }}
                role="button"
                aria-label="Tirar dúvidas com especialistas"
              >
                <i className="fas fa-question-circle mr-1" aria-hidden="true"></i>
                Tire suas dúvidas com nossos especialistas
              </a>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
