import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-300 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between mb-8">
            <div className="mb-6 md:mb-0">
              <h3 className="font-heading font-bold text-xl mb-3 text-white">Como Vender para o Governo</h3>
              <p className="mb-3">O curso completo para pequenas empresas que desejam vender para o setor público.</p>
              <p>© {new Date().getFullYear()} VendaMais. Todos os direitos reservados.</p>
            </div>
            <div>
              <h4 className="font-bold mb-3 text-white">Links Rápidos</h4>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white transition">Política de Privacidade</a></li>
                <li><a href="#" className="hover:text-white transition">Termos de Uso</a></li>
                <li><a href="#" className="hover:text-white transition">Política de Cookies</a></li>
                <li><a href="#" className="hover:text-white transition">Garantia de Reembolso</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-6 text-sm text-center">
            <p>Este produto é protegido por direitos autorais. A reprodução ou distribuição deste material sem autorização é estritamente proibida.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
