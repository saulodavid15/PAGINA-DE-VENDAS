import React, { useState } from 'react';
import CountdownTimer from './CountdownTimer';
import { useMobile } from '@/hooks/use-mobile';

const PurchaseSection: React.FC = () => {
  const [selectedPlan, setSelectedPlan] = useState<'basic' | 'premium'>('basic');
  const isMobile = useMobile();
  
  const plans = {
    basic: {
      title: "Plano Essencial",
      originalPrice: 129.90,
      currentPrice: 67.90,
      features: [
        { text: "Acesso aos 6 módulos do curso", included: true },
        { text: "Modelos básicos de documentos e propostas", included: true },
        { text: "Ferramenta gratuita de email marketing", included: true, highlight: true },
        { text: "Acesso vitalício ao material", included: true },
        { text: "Comunidade de fornecedores", included: true },
        { text: "Certificado de conclusão", included: true },
        { text: "Atendimento prioritário", included: false },
        { text: "Consultoria individual (30 min)", included: false },
        { text: "Modelos premium e templates exclusivos", included: false },
        { text: "Acesso antecipado a atualizações", included: false },
      ],
      bonus: "Treinamento básico de Email Marketing"
    },
    premium: {
      title: "Plano Completo",
      originalPrice: 199.90,
      currentPrice: 97.90,
      features: [
        { text: "Acesso aos 6 módulos do curso", included: true },
        { text: "Modelos avançados de documentos e propostas", included: true },
        { text: "Ferramenta gratuita de email marketing", included: true, highlight: true },
        { text: "Acesso vitalício ao material e todas as atualizações", included: true },
        { text: "Acesso VIP à comunidade de fornecedores", included: true },
        { text: "Certificado de conclusão avançado", included: true },
        { text: "Atendimento prioritário 24/7", included: true },
        { text: "Consultoria individual (60 min)", included: true },
        { text: "Pacote completo de modelos premium e templates exclusivos", included: true },
        { text: "Acesso antecipado a todas as atualizações", included: true },
      ],
      bonus: "Masterclass completa de Email Marketing + Certificado Especial"
    }
  };
  
  const currentPlan = plans[selectedPlan];
  
  // Configurar a data final da promoção (7 dias a partir de agora)
  const endDate = new Date();
  endDate.setDate(endDate.getDate() + 7);
  
  return (
    <section id="comprar-agora" className="py-10 md:py-16 bg-primary text-white relative" style={{backgroundColor: '#003366'}}>
      {/* Onda decorativa superior */}
      <div className="absolute top-0 left-0 w-full overflow-hidden" style={{height: '50px', transform: 'translateY(-49px) rotate(180deg)'}}>
        <svg viewBox="0 0 500 150" preserveAspectRatio="none" style={{height: '100%', width: '100%'}}>
          <path d="M0.00,49.98 C149.99,150.00 349.20,-49.98 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style={{stroke: 'none', fill: '#fff'}}></path>
        </svg>
      </div>
      
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="font-heading mb-3 md:mb-4 text-center animate-fade-in-up text-2xl md:text-3xl" style={{animationDelay: '0.1s'}}>
            Invista Hoje no Seu Futuro Como Fornecedor
          </h2>
          <p className="mb-6 text-center text-sm md:text-base animate-fade-in-up" style={{animationDelay: '0.2s'}}>
            Um único contrato com o governo pode representar milhares de reais em faturamento garantido
          </p>
          
          {/* Opções de Planos */}
          <div className="flex justify-center space-x-2 md:space-x-4 mb-6 md:mb-10 animate-fade-in-up" style={{animationDelay: '0.3s'}}>
            <button 
              className={`py-2 md:py-3 px-3 md:px-6 rounded-lg transition-all duration-300 flex items-center text-sm md:text-base ${selectedPlan === 'basic' ? 'bg-white text-primary font-bold shadow-lg scale-105' : 'bg-white/20 hover:bg-white/30 text-white'}`}
              onClick={() => setSelectedPlan('basic')}
            >
              <i className={`fas fa-check-circle mr-1 md:mr-2 ${selectedPlan === 'basic' ? 'text-success' : 'text-white/70'}`}></i>
              Plano Essencial
            </button>
            <button 
              className={`py-2 md:py-3 px-3 md:px-6 rounded-lg transition-all duration-300 flex items-center text-sm md:text-base ${selectedPlan === 'premium' ? 'bg-white text-primary font-bold shadow-lg scale-105' : 'bg-white/20 hover:bg-white/30 text-white'}`}
              onClick={() => setSelectedPlan('premium')}
            >
              <i className={`fas fa-crown mr-1 md:mr-2 ${selectedPlan === 'premium' ? 'text-accent' : 'text-white/70'}`}></i>
              Plano Completo
            </button>
          </div>
          
          <div className="bg-white text-gray-800 rounded-xl shadow-2xl overflow-hidden mb-6 md:mb-8 animate-fade-in-up" style={{animationDelay: '0.4s'}}>
            <div className={`${selectedPlan === 'premium' ? 'bg-accent' : 'bg-secondary'} text-white py-3 md:py-4 text-center relative overflow-hidden`}>
              <h3 className="font-heading font-bold text-xl md:text-2xl relative z-10">{currentPlan.title}</h3>
              <p className="relative z-10 text-sm md:text-base">Curso Online: Como Vender para o Governo</p>
              {selectedPlan === 'premium' && (
                <div className="absolute top-0 right-0 bg-white/20 py-1 px-3 md:px-4 rounded-bl-lg text-xs md:text-sm font-bold animate-pulse-slow">
                  RECOMENDADO
                </div>
              )}
            </div>
            
            <div className="p-4 md:p-8">
              {/* Preços e Badge Promocional - Versão Mobile e Desktop */}
              <div className={`flex ${isMobile ? 'flex-col' : 'justify-between'} items-start md:items-center mb-4 md:mb-6 pb-4 md:pb-6 border-b border-gray-200`}>
                <div>
                  <p className="text-gray-500 line-through text-sm md:text-base">De R$ {currentPlan.originalPrice.toFixed(2)}</p>
                  <p className="text-3xl md:text-4xl font-bold text-primary">R$ {currentPlan.currentPrice.toFixed(2)}</p>
                  <p className="text-xs md:text-sm text-gray-500">Pagamento único</p>
                </div>
                
                <div className={`${selectedPlan === 'premium' ? 'bg-accent' : 'bg-warning'} text-white font-bold py-1 md:py-2 px-3 md:px-4 rounded-full text-xs md:text-sm animate-pulse-slow ${isMobile ? 'mt-3' : ''}`}>
                  PROMOÇÃO POR TEMPO LIMITADO
                </div>
              </div>
              
              {/* Features do Plano */}
              <div className="mb-4 md:mb-6">
                <h4 className="font-bold text-lg md:text-xl mb-2 md:mb-3">O que está incluído:</h4>
                <ul className="space-y-2 md:space-y-3">
                  {currentPlan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      {feature.included ? (
                        <i className={`fas fa-check-circle ${feature.highlight ? 'text-accent' : 'text-success'} mt-1 mr-2 text-lg md:text-xl`}></i>
                      ) : (
                        <i className="fas fa-times-circle text-gray-300 mt-1 mr-2 text-lg md:text-xl"></i>
                      )}
                      <span className={`${feature.included ? '' : 'text-gray-400'} text-sm md:text-base`}>
                        {feature.highlight ? <strong>{feature.text}</strong> : feature.text}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* Bônus */}
              <div className={`${selectedPlan === 'premium' ? 'bg-accent bg-opacity-10 border border-accent/30' : 'bg-gray-100'} p-3 md:p-4 mb-4 md:mb-6 rounded-lg`}>
                <h4 className={`font-bold text-base md:text-lg mb-1 md:mb-2 ${selectedPlan === 'premium' ? 'text-accent' : 'text-secondary'}`}>
                  BÔNUS {selectedPlan === 'premium' ? 'PREMIUM' : 'ESPECIAL'}!
                </h4>
                <p className="text-sm md:text-base">
                  <i className={`fas ${selectedPlan === 'premium' ? 'fa-gem' : 'fa-envelope'} ${selectedPlan === 'premium' ? 'text-accent' : 'text-secondary'} mr-2`}></i>
                  {currentPlan.bonus}
                </p>
                <p className="mt-1 md:mt-2 text-xs md:text-sm text-gray-600">
                  {selectedPlan === 'premium' 
                    ? 'Domine o email marketing com estratégias avançadas e exclusivas, plus uma consultoria individual para aplicar no seu negócio.' 
                    : 'Aprenda a conquistar contratos governamentais utilizando estratégias básicas de email marketing gratuitas.'}
                </p>
              </div>
              
              {/* Botão de Compra - Otimizado para acessibilidade */}
              <div className="text-center">
                <a 
                  href="https://pay.exemplo.com/como-vender-governo" 
                  aria-label={`Comprar ${currentPlan.title} por R$ ${currentPlan.currentPrice.toFixed(2)}`}
                  rel="noopener"
                  className={`${selectedPlan === 'premium' ? 'bg-accent' : 'bg-secondary'} hover:bg-opacity-90 text-white font-bold py-3 md:py-4 px-6 md:px-8 rounded-lg inline-block text-base md:text-xl w-full transition shadow-lg btn-hover-effect`}
                  role="button"
                  onClick={(e) => {
                    // Eventos de análise podem ser adicionados aqui
                    // Por enquanto vamos apenas prevenir o padrão para simulação
                    e.preventDefault();
                    alert(`Obrigado por seu interesse no ${currentPlan.title}! Em um site real, você seria redirecionado para o checkout.`);
                  }}
                >
                  COMPRAR AGORA POR APENAS R$ {currentPlan.currentPrice.toFixed(2)}
                </a>
                <div className="flex justify-center mt-3 md:mt-4 items-center">
                  <img 
                    src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80" 
                    alt="Pagamento seguro" 
                    className="h-4 md:h-6 mr-1 md:mr-2"
                    loading="lazy"
                    width="30"
                    height="24"
                  />
                  <p className="text-xs md:text-sm text-gray-500">Pagamento 100% seguro</p>
                </div>
              </div>
            </div>
            
            {/* Garantia */}
            <div className="bg-gray-100 p-3 md:p-4 flex items-center justify-center gap-2 md:gap-3 text-xs md:text-base">
              <div className="bg-success text-white p-2 md:p-3 rounded-full animate-pulse-slow">
                <i className="fas fa-shield-alt text-sm md:text-base"></i>
              </div>
              <p className="font-bold">Garantia de 7 dias ou seu dinheiro de volta</p>
            </div>
          </div>
          
          {/* Countdown e Info */}
          <div className="flex flex-col md:flex-row justify-center items-center gap-4 md:gap-6 mb-4 animate-fade-in-up" style={{animationDelay: '0.5s'}}>
            <CountdownTimer endDate={endDate} />
            
            <div className="text-center text-sm md:text-base">
              <p className="mb-1 md:mb-2">
                <i className="fas fa-bolt text-accent"></i> Curso em pré-lançamento com valor exclusivo!
              </p>
              <p>
                <i className="fas fa-clock text-accent"></i> Preço promocional por tempo limitado!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PurchaseSection;
