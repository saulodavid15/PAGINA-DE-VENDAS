import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useMobile } from '@/hooks/use-mobile';

interface CountdownTimerProps {
  endDate: Date;
}

interface TimeLeft {
  dias?: number;
  horas?: number;
  minutos?: number;
  segundos?: number;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ endDate }) => {
  const isMobile = useMobile();
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Usar useCallback para evitar redefinições da função a cada render
  const calculateTimeLeft = useCallback(() => {
    try {
      const difference = Number(endDate) - Number(new Date());
      let timeLeft: TimeLeft = {};

      if (difference > 0) {
        // Constantes para melhorar legibilidade
        const SECOND = 1000;
        const MINUTE = SECOND * 60;
        const HOUR = MINUTE * 60;
        const DAY = HOUR * 24;

        timeLeft = {
          dias: Math.floor(difference / DAY),
          horas: Math.floor((difference % DAY) / HOUR),
          minutos: Math.floor((difference % HOUR) / MINUTE),
          segundos: Math.floor((difference % MINUTE) / SECOND),
        };
      }

      return timeLeft;
    } catch (error) {
      console.error('Erro ao calcular tempo restante:', error);
      return {};
    }
  }, [endDate]); // endDate como dependência

  const [timeLeft, setTimeLeft] = useState<TimeLeft>(calculateTimeLeft());

  useEffect(() => {
    // Função de atualização separada para evitar problemas
    const updateTimer = () => {
      setTimeLeft(calculateTimeLeft());
    };
    
    // Executa uma vez imediatamente
    updateTimer();
    
    // Limpar timer existente se houver
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    // Configura o novo timer
    timerRef.current = setInterval(updateTimer, 1000);

    // Limpa o intervalo quando o componente é desmontado
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [calculateTimeLeft]); // Apenas calculateTimeLeft como dependência

  // Tipos de abreviações para dispositivos móveis
  const getLabelForInterval = useCallback((interval: string): string => {
    if (isMobile) {
      switch (interval) {
        case 'dias': return 'd';
        case 'horas': return 'h';
        case 'minutos': return 'm';
        case 'segundos': return 's';
        default: return interval;
      }
    }
    return interval;
  }, [isMobile]);

  // Gerar componentes de tempo - memoizar para evitar re-renderizações desnecessárias
  const timeComponents = React.useMemo(() => {
    return Object.keys(timeLeft).map((interval) => {
      if (!timeLeft[interval as keyof TimeLeft] && timeLeft[interval as keyof TimeLeft] !== 0) {
        return null;
      }

      return (
        <div 
          key={interval} 
          className={`flex flex-col items-center bg-white text-primary ${isMobile ? 'px-2 py-1' : 'px-4 py-2'} rounded-lg shadow-md`}
        >
          <span className={`${isMobile ? 'text-lg' : 'text-2xl'} font-bold`}>
            {String(timeLeft[interval as keyof TimeLeft]).padStart(2, '0')}
          </span>
          <span className="text-xs text-gray-500">{getLabelForInterval(interval)}</span>
        </div>
      );
    }).filter(Boolean); // Remove itens null
  }, [timeLeft, isMobile, getLabelForInterval]);

  return (
    <div className={`${isMobile ? 'py-2 px-3' : 'py-4 px-6'} bg-red-500 text-white rounded-lg shadow-lg animate-pulse-slow`}>
      <div className="flex flex-col items-center">
        <h4 className={`font-bold ${isMobile ? 'text-sm' : 'text-base'} mb-1 md:mb-2 flex items-center`}>
          <i className="fas fa-clock mr-1 md:mr-2"></i>
          OFERTA POR TEMPO LIMITADO
        </h4>
        
        {timeComponents.length ? (
          <div className="flex space-x-1 md:space-x-3 mt-1 md:mt-2">
            {timeComponents}
          </div>
        ) : (
          <p className={`${isMobile ? 'text-sm' : 'text-base'}`}>Oferta encerrada!</p>
        )}
      </div>
    </div>
  );
};

export default CountdownTimer;