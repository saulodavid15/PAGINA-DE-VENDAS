import React, { useState } from 'react';

const Introduction: React.FC = () => {
  const [activeTab, setActiveTab] = useState(0);
  
  const benefitTabs = [
    { 
      icon: "fas fa-envelope",
      title: "Email Marketing",
      content: "Domine o email marketing utilizando uma ferramenta 100% gratuita e legal para conseguir contratos governamentais sem complicações."
    },
    { 
      icon: "fas fa-file-alt",
      title: "Modelos Prontos",
      content: "Receba templates de propostas, documentos e emails que já foram testados e aprovados em processos reais de vendas para o governo."
    },
    { 
      icon: "fas fa-graduation-cap",
      title: "Passo a Passo",
      content: "Aprenda de forma sequencial e estruturada, com exemplos claros e direcionamento prático para aplicação imediata."
    },
    { 
      icon: "fas fa-coins",
      title: "Economia",
      content: "Economize tempo e dinheiro evitando erros comuns que desclassificam 90% dos novos fornecedores logo no início."
    }
  ];

  return (
    <section className="py-12 bg-white relative">
      {/* Onda decorativa superior */}
      <div className="absolute top-0 left-0 w-full overflow-hidden" style={{height: '70px', transform: 'translateY(-69px) rotate(180deg)'}}>
        <svg viewBox="0 0 500 150" preserveAspectRatio="none" style={{height: '100%', width: '100%'}}>
          <path d="M0.00,49.98 C149.99,150.00 349.20,-49.98 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style={{stroke: 'none', fill: '#f9fafb'}}></path>
        </svg>
      </div>
      
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-gradient-to-br from-white to-gray-50 rounded-lg p-8 shadow-lg border border-muted/30">
          <h2 className="font-heading text-primary text-center mb-8">Você sabia que...</h2>
          <p className="mb-4 animate-fade-in-up" style={{animationDelay: '0.1s', animationDuration: '0.8s'}}>
            O governo compra de tudo, todos os dias — e que <span className="font-bold">você pode ser o próximo fornecedor</span>?
          </p>
          <p className="mb-4 animate-fade-in-up" style={{animationDelay: '0.3s', animationDuration: '0.8s'}}>
            Mesmo sendo MEI ou pequena empresa, é possível vender para escolas, prefeituras, hospitais e órgãos públicos, e o melhor: <span className="font-bold text-secondary">sem precisar participar de grandes licitações</span>.
          </p>
          <p className="mb-4 animate-fade-in-up" style={{animationDelay: '0.5s', animationDuration: '0.8s'}}>
            Neste curso prático, você vai aprender passo a passo como identificar oportunidades reais de vendas, cadastrar sua empresa corretamente, participar de dispensas de licitação e enviar propostas vencedoras.
          </p>
          <p className="mb-6 font-bold text-secondary animate-fade-in-up" style={{animationDelay: '0.7s', animationDuration: '0.8s'}}>
            Com um investimento acessível, você terá acesso a estratégias validadas, exemplos reais e materiais prontos para colocar em prática hoje mesmo.
          </p>
          
          <div className="bg-secondary text-white p-6 rounded-lg mt-8 shadow-lg transform transition-all duration-500 hover:shadow-xl">
            <h3 className="font-bold text-2xl mb-6 text-center">BENEFÍCIOS PRÁTICOS DO TREINAMENTO</h3>
            
            {/* Tabs de navegação para benefícios */}
            <div className="flex justify-between mb-6 border-b border-white/20 pb-2 overflow-x-auto">
              {benefitTabs.map((tab, index) => (
                <button 
                  key={index}
                  onClick={() => setActiveTab(index)}
                  className={`px-4 py-2 mx-1 rounded-t-lg transition-all flex items-center ${activeTab === index ? 'bg-white text-secondary font-bold shadow-lg' : 'bg-white/10 hover:bg-white/20'}`}
                >
                  <i className={`${tab.icon} mr-2`}></i>
                  <span className="hidden md:inline">{tab.title}</span>
                </button>
              ))}
            </div>
            
            {/* Conteúdo da tab ativa */}
            <div className="min-h-[150px] flex items-center justify-center p-4 bg-white/10 rounded-lg animate-fade-in-up" style={{animationDuration: '0.5s'}}>
              <div className="text-center">
                <i className={`${benefitTabs[activeTab].icon} text-4xl text-accent mb-4 animate-bounce-slow`}></i>
                <h4 className="text-xl font-bold mb-3">{benefitTabs[activeTab].title}</h4>
                <p>{benefitTabs[activeTab].content}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              <div className="flex items-start bg-white/10 p-4 rounded-lg hover:bg-white/20 transition-all interactive-element">
                <i className="fas fa-check-circle mt-1 mr-3 text-accent"></i>
                <span>Domine o email marketing utilizando uma ferramenta 100% gratuita e legal</span>
              </div>
              <div className="flex items-start bg-white/10 p-4 rounded-lg hover:bg-white/20 transition-all interactive-element">
                <i className="fas fa-check-circle mt-1 mr-3 text-accent"></i>
                <span>Saiba como criar campanhas que convertem e evite cair na caixa de spam</span>
              </div>
              <div className="flex items-start bg-white/10 p-4 rounded-lg hover:bg-white/20 transition-all interactive-element">
                <i className="fas fa-check-circle mt-1 mr-3 text-accent"></i>
                <span>Aumente suas chances de fechar contratos com o governo em até 5x</span>
              </div>
              <div className="flex items-start bg-white/10 p-4 rounded-lg hover:bg-white/20 transition-all interactive-element">
                <i className="fas fa-check-circle mt-1 mr-3 text-accent"></i>
                <span>Aplique imediatamente os conhecimentos com nossos modelos prontos</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Introduction;
