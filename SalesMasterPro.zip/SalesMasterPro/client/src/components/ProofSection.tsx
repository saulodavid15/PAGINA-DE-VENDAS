import React from 'react';

const ProofSection: React.FC = () => {
  return (
    <section className="py-14 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="font-heading font-bold text-3xl mb-2 text-center text-primary">Resultados Reais</h2>
          <p className="text-center text-lg mb-10 text-gray-600">Pequenas empresas como a sua já estão lucrando com o governo</p>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&h=200&q=80" 
                  alt="João Mendes" 
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="font-bold text-lg">João Mendes</h3>
                  <p className="text-gray-600">Microempresário - MG</p>
                </div>
              </div>
              <p className="italic mb-4">
                "Comprei esse curso achando que era mais um, mas em menos de 2 meses fechei meu primeiro contrato com a prefeitura da minha cidade. Investimento ridículo perto do que aprendi."
              </p>
              <div className="flex items-center text-accent">
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&h=200&q=80" 
                  alt="Carla Ribeiro" 
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="font-bold text-lg">Carla Ribeiro</h3>
                  <p className="text-gray-600">MEI - SP</p>
                </div>
              </div>
              <p className="italic mb-4">
                "Sempre tive medo de vender para o governo por causa da burocracia. Agora sei exatamente o que fazer. Já estou participando de dispensas semanais."
              </p>
              <div className="flex items-center text-accent">
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
              </div>
            </div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-4 rounded-lg shadow border-2 border-success">
              <h3 className="font-bold text-center mb-2 text-success">Contrato Municipal</h3>
              <img 
                src="https://images.unsplash.com/photo-1579389082947-e54d8e911928?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                alt="Extrato de venda para prefeitura" 
                className="w-full h-40 object-cover rounded mb-2"
              />
              <p className="text-sm text-gray-600 text-center">Extrato de venda para prefeitura</p>
              <p className="text-success font-bold text-center mt-2">R$ 32.450,00</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow border-2 border-success">
              <h3 className="font-bold text-center mb-2 text-success">Portal de Compras</h3>
              <img 
                src="https://images.unsplash.com/photo-1573495804664-b1c0849e5349?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                alt="Tela de portal de compras" 
                className="w-full h-40 object-cover rounded mb-2"
              />
              <p className="text-sm text-gray-600 text-center">Acesso fácil às oportunidades</p>
              <p className="text-success font-bold text-center mt-2">+300 oportunidades mensais</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow border-2 border-success">
              <h3 className="font-bold text-center mb-2 text-success">Nota Fiscal</h3>
              <img 
                src="https://images.unsplash.com/photo-1554224155-1696413565d3?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                alt="Nota fiscal de venda para governo" 
                className="w-full h-40 object-cover rounded mb-2"
              />
              <p className="text-sm text-gray-600 text-center">Exemplo de nota fiscal emitida</p>
              <p className="text-success font-bold text-center mt-2">R$ 18.750,00</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProofSection;
