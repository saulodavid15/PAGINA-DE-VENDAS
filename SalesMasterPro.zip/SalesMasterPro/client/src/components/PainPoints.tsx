import React from 'react';

const painPoints = [
  {
    icon: "fas fa-question",
    title: "Não sabe como começar a vender para o governo",
    description: "A burocracia parece assustadora e você não sabe por onde começar o processo",
    solution: "Você aprenderá o caminho exato, passo a passo, sem mistificações"
  },
  {
    icon: "fas fa-building",
    title: "Já ouviu que só \"empresa grande ganha\"",
    description: "Disseram que seu pequeno negócio não tem chances contra grandes fornecedores",
    solution: "Descubra nichos específicos onde pequenas empresas têm vantagem"
  },
  {
    icon: "fas fa-file-alt",
    title: "Acha que é difícil ou burocrático",
    description: "A quantidade de documentos e requisitos parece impossível de cumprir",
    solution: "Receba modelos prontos e checklists para organizar tudo facilmente"
  },
  {
    icon: "fas fa-tired",
    title: "Está cansado de depender só de clientes particulares",
    description: "Gostaria de ter o governo como cliente fiel e pagador garantido",
    solution: "Aprenda a usar email marketing gratuito para conseguir contratos"
  }
];

const PainPoints: React.FC = () => {
  return (
    <section className="py-14 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="font-heading mb-8 text-center text-primary">Você Se Identifica Com Isso?</h2>
          
          <div className="grid md:grid-cols-2 gap-6 mb-10">
            {painPoints.map((point, index) => (
              <div key={index} className="flex flex-col p-5 bg-gray-50 rounded-lg shadow-sm border border-gray-100">
                <div className="flex items-start mb-3">
                  <div className="bg-primary text-white p-3 rounded-full mr-4">
                    <i className={point.icon}></i>
                  </div>
                  <div>
                    <h3 className="font-bold mb-2">{point.title}</h3>
                    <p className="text-gray-600">{point.description}</p>
                  </div>
                </div>
                <div className="mt-3 bg-accent bg-opacity-10 p-3 rounded-lg border-l-4 border-accent">
                  <p className="font-bold text-secondary flex items-center">
                    <i className="fas fa-lightbulb mr-2 text-accent"></i>
                    <span>Solução: {point.solution}</span>
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="bg-secondary text-white p-8 rounded-lg shadow-md">
            <h3 className="font-heading font-bold text-2xl mb-4 text-center">A Boa Notícia...</h3>
            <p className="mb-4 text-center">
              É possível vender para o governo, mesmo sendo MEI ou pequena empresa, sem complicações e sem concorrer com as grandes.
            </p>
            <p className="font-bold text-center">
              E o melhor: com margens de lucro muito maiores do que você consegue no mercado convencional!
            </p>
            <div className="mt-6 bg-white text-primary p-4 rounded-lg">
              <p className="font-bold text-center text-xl">APLIQUE NA PRÁTICA!</p>
              <p className="text-center">Todas as estratégias ensinadas no curso são 100% aplicáveis no dia a dia do seu negócio, incluindo o uso de uma ferramenta gratuita de email marketing para aumentar suas chances de sucesso.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PainPoints;
