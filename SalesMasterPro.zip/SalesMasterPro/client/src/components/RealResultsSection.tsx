import React, { useState } from 'react';

const RealResultsSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState(0);
  
  const resultTabs = [
    {
      title: "Vendas para Prefeituras",
      icon: "fas fa-building",
      content: {
        text: "MEI forneceu material de escritório para prefeitura do interior de Minas Gerais, no valor de R$ 17.890,00 através de processo de dispensa de licitação.",
        imageUrl: "https://portalamm.org.br/wp-content/uploads/2022/01/licitacao-1.png",
        stats: [
          { label: "Valor do Contrato", value: "R$ 17.890,00" },
          { label: "Tempo de Fechamento", value: "12 dias" },
          { label: "Lucro líquido", value: "35%" }
        ]
      }
    },
    {
      title: "Vendas para Escolas",
      icon: "fas fa-school",
      content: {
        text: "Microempresa forneceu móveis para três escolas municipais no Paraná, ganhando contrato de R$ 45.230,00 com pagamento garantido.",
        imageUrl: "https://www.comprasgovernamentais.gov.br/images/conteudo/banner/banner-comprasnetcontratos.jpg",
        stats: [
          { label: "Valor do Contrato", value: "R$ 45.230,00" },
          { label: "Tempo de Fechamento", value: "28 dias" },
          { label: "Lucro líquido", value: "42%" }
        ]
      }
    },
    {
      title: "Vendas para Hospitais",
      icon: "fas fa-hospital",
      content: {
        text: "Pequeno distribuidor faturou R$ 102.450,00 fornecendo produtos de limpeza para hospital estadual em São Paulo por meio de cotação eletrônica.",
        imageUrl: "https://www.marilia.unesp.br/Home/Imprensa/licitacao-nova.jpg",
        stats: [
          { label: "Valor do Contrato", value: "R$ 102.450,00" },
          { label: "Tempo de Fechamento", value: "35 dias" },
          { label: "Lucro líquido", value: "28%" }
        ]
      }
    }
  ];

  const currentTab = resultTabs[activeTab];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <span className="bg-accent text-white text-sm font-bold px-3 py-1 rounded-full inline-block mb-4">RESULTADOS REAIS</span>
            <h2 className="font-heading text-primary mb-4">Extratos de Vendas para o Governo</h2>
            <p className="text-gray-700">
              Veja exemplos reais de como pequenos empreendedores estão faturando com vendas para o setor público. Estes são resultados que nossos alunos alcançaram após aplicarem as estratégias ensinadas no curso.
            </p>
          </div>
          
          {/* Abas de Navegação */}
          <div className="flex justify-center mb-8 border-b border-gray-200 overflow-x-auto">
            {resultTabs.map((tab, index) => (
              <button
                key={index}
                onClick={() => setActiveTab(index)}
                className={`py-3 px-5 flex items-center transition-all ${activeTab === index ? 'border-b-2 border-accent text-accent font-bold' : 'text-gray-600 hover:text-accent'}`}
              >
                <i className={`${tab.icon} mr-2`}></i>
                <span>{tab.title}</span>
              </button>
            ))}
          </div>
          
          {/* Conteúdo da Aba Selecionada */}
          <div className="bg-white rounded-xl shadow-lg overflow-hidden animate-fade-in-up" style={{animationDuration: '0.5s'}}>
            <div className="grid md:grid-cols-2 gap-0">
              <div className="p-8">
                <h3 className="font-bold text-2xl text-primary mb-4">{currentTab.title}</h3>
                <p className="text-gray-700 mb-6">{currentTab.content.text}</p>
                
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {currentTab.content.stats.map((stat, idx) => (
                    <div key={idx} className="bg-gray-50 p-4 rounded-lg text-center">
                      <p className="text-gray-500 text-sm">{stat.label}</p>
                      <p className="font-bold text-xl text-accent">{stat.value}</p>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6">
                  <a 
                    href="#comprar-agora" 
                    className="inline-block bg-accent hover:bg-opacity-90 text-white font-bold py-3 px-6 rounded-lg btn-hover-effect"
                    style={{backgroundColor: '#E67E22'}}
                  >
                    QUERO RESULTADOS COMO ESTES
                  </a>
                </div>
              </div>
              
              <div className="bg-gray-100 flex items-center justify-center p-4">
                <div className="relative w-full h-full max-h-80 overflow-hidden rounded-lg shadow-md">
                  <img 
                    src={currentTab.content.imageUrl} 
                    alt={`Exemplo de ${currentTab.title}`}
                    className="w-full h-full object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                  <div className="absolute top-0 right-0 bg-accent text-white text-xs px-2 py-1 rounded-bl-lg">
                    Documento Real
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-12 bg-primary/5 border border-primary/20 rounded-lg p-6 animate-fade-in-up" style={{animationDelay: '0.3s'}}>
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/6 text-center mb-4 md:mb-0">
                <div className="bg-primary text-white rounded-full p-4 inline-block">
                  <i className="fas fa-lightbulb text-2xl"></i>
                </div>
              </div>
              <div className="md:w-5/6">
                <h4 className="font-bold text-primary text-xl mb-2">Você sabia?</h4>
                <p className="text-gray-700">
                  O governo brasileiro compra mais de R$ 50 bilhões por ano em produtos e serviços. A legislação prevê tratamento diferenciado para Micro e Pequenas Empresas, facilitando sua participação nas licitações. As compras diretas (dispensas de licitação) têm limite de até R$ 50.000,00 e são uma excelente porta de entrada para novos fornecedores.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RealResultsSection;