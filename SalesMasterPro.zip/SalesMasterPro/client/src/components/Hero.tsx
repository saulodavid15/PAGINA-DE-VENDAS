import React from 'react';
import { Link } from 'wouter';
import { useMobile } from '@/hooks/use-mobile';

const Hero: React.FC = () => {
  const isMobile = useMobile();
  
  return (
    <section className="bg-primary text-white pt-20 pb-12 md:py-20 parallax-bg" style={{backgroundImage: 'linear-gradient(rgba(0, 51, 102, 0.9), rgba(0, 51, 102, 0.95)), url("https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1600&q=80")'}}>
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-6 md:gap-8 items-center">
            <div className="animate-fade-in-up text-center md:text-left" style={{animationDelay: '0.3s', animationDuration: '1s'}}>
              <span className="bg-accent text-white px-3 py-1 rounded-full text-xs md:text-sm font-bold inline-block mb-3 md:mb-4 animate-pulse-slow">CURSO EXCLUSIVO</span>
              <h1 className="font-heading mb-3 md:mb-4 leading-tight text-2xl md:text-3xl lg:text-4xl">
                DESCUBRA Como <span className="text-accent">FATURAR</span> Vendendo para o Governo <span className="text-accent">SEM COMPLICAÇÕES</span>
              </h1>
              <p className="mb-4 md:mb-6 text-sm md:text-base">
                Aprenda a vender para prefeituras, escolas, hospitais e órgãos públicos mesmo sem experiência prévia e domine o email marketing com uma ferramenta 100% GRATUITA.
              </p>
              <div className="flex flex-col gap-4 mb-4">
                <Link href="#comprar-agora" className="bg-accent hover:bg-opacity-90 text-white font-bold py-3 md:py-4 px-4 md:px-6 rounded-lg text-center transition shadow-xl btn-hover-effect text-sm md:text-base">
                  QUERO COMEÇAR A VENDER PARA O GOVERNO AGORA!
                </Link>
              </div>
              <p className="text-gray-300 text-xs md:text-sm"><i className="fas fa-lock mr-1"></i> Pagamento 100% seguro • Garantia de 7 dias</p>
            </div>
            
            {/* Seção móvel: a imagem vem primeiro em dispositivos de desktop, mas em mobile vem depois do texto */}
            {!isMobile && (
              <div className="relative animate-fade-in-right" style={{animationDelay: '0.6s', animationDuration: '1s'}}>
                <div className="bg-white/10 backdrop-blur-sm p-2 rounded-lg shadow-xl">
                  <img 
                    src="https://images.unsplash.com/photo-1607703703674-df96af81dffa?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                    alt="Empresário analisando contrato" 
                    className="rounded-lg shadow-xl hover:shadow-2xl transition-all duration-300 interactive-element"
                  />
                </div>
                <div className="absolute -bottom-5 -left-5 bg-white text-primary p-3 md:p-4 rounded-lg shadow-lg animate-bounce-slow" style={{animation: 'bounce 3s infinite'}}>
                  <p className="font-bold text-sm md:text-base">A partir de:</p>
                  <p className="text-xl md:text-2xl font-extrabold text-secondary">R$ 67,90</p>
                  <p className="text-xs text-gray-600">Ou R$ 97,90 <span className="bg-accent text-white text-xs px-1 rounded">premium</span></p>
                </div>
              </div>
            )}
            
            {/* Versão móvel da imagem e preço */}
            {isMobile && (
              <div className="relative mt-4">
                <div className="bg-white/10 backdrop-blur-sm p-2 rounded-lg shadow-xl">
                  <img 
                    src="https://images.unsplash.com/photo-1607703703674-df96af81dffa?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                    alt="Empresário analisando contrato" 
                    className="rounded-lg shadow-xl transition-all duration-300 w-full"
                  />
                </div>
                <div className="absolute -bottom-4 -right-2 bg-white text-primary p-3 rounded-lg shadow-lg" style={{maxWidth: '140px'}}>
                  <p className="font-bold text-sm">A partir de:</p>
                  <p className="text-xl font-extrabold text-secondary">R$ 67,90</p>
                  <p className="text-xs text-gray-600">Ou R$ 97,90 <span className="bg-accent text-white text-xs px-1 rounded">premium</span></p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 w-full overflow-hidden" style={{height: '50px', transform: 'translateY(1px)'}}>
        <svg viewBox="0 0 500 150" preserveAspectRatio="none" style={{height: '100%', width: '100%'}}>
          <path d="M0.00,49.98 C149.99,150.00 349.20,-49.98 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style={{stroke: 'none', fill: '#f9fafb'}}></path>
        </svg>
      </div>
    </section>
  );
};

export default Hero;
