import React, { useState } from 'react';
import { Link } from 'wouter';

const CallToAction: React.FC = () => {
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <section className="py-12 text-white relative" style={{backgroundColor: '#27AE60'}}>
      {/* Onda decorativa superior */}
      <div className="absolute top-0 left-0 w-full overflow-hidden" style={{height: '70px', transform: 'translateY(-69px) rotate(180deg)'}}>
        <svg viewBox="0 0 500 150" preserveAspectRatio="none" style={{height: '100%', width: '100%'}}>
          <path d="M0.00,49.98 C149.99,150.00 349.20,-49.98 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style={{stroke: 'none', fill: '#fff'}}></path>
        </svg>
      </div>
      
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-heading mb-4 animate-fade-in-up" style={{animationDelay: '0.1s'}}>
            Não Perca Mais Tempo!
          </h2>
          <p className="mb-8 animate-fade-in-up" style={{animationDelay: '0.3s'}}>
            Enquanto você decide, outras pequenas empresas já estão aproveitando as oportunidades com o governo.
          </p>
          
          <div className="bg-white text-primary p-6 rounded-lg mb-8 shadow-xl transform transition-all duration-500 hover:shadow-2xl hover:-translate-y-2 animate-fade-in-up" style={{animationDelay: '0.5s'}}>
            <h3 className="font-bold text-2xl mb-4">O QUE VOCÊ VAI LEVAR HOJE:</h3>
            <div className="grid md:grid-cols-2 gap-4 text-left">
              <div className="flex items-start p-3 hover:bg-gray-50 rounded-lg transition-colors duration-300">
                <i className="fas fa-check-circle text-accent mt-1 mr-3 text-xl animate-pulse-slow"></i>
                <span>Curso completo "Como Vender para o Governo"</span>
              </div>
              <div className="flex items-start p-3 hover:bg-gray-50 rounded-lg transition-colors duration-300">
                <i className="fas fa-check-circle text-accent mt-1 mr-3 text-xl animate-pulse-slow"></i>
                <span>Ferramenta gratuita de email marketing</span>
              </div>
              <div className="flex items-start p-3 hover:bg-gray-50 rounded-lg transition-colors duration-300">
                <i className="fas fa-check-circle text-accent mt-1 mr-3 text-xl animate-pulse-slow"></i>
                <span>Modelos prontos para usar na prática</span>
              </div>
              <div className="flex items-start p-3 hover:bg-gray-50 rounded-lg transition-colors duration-300">
                <i className="fas fa-check-circle text-accent mt-1 mr-3 text-xl animate-pulse-slow"></i>
                <span>Estratégias testadas e comprovadas</span>
              </div>
            </div>
            
            <div className="mt-6 p-3 bg-accent/10 border border-accent/30 rounded-lg">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-accent text-white rounded-full p-3 mr-3">
                  <i className="fas fa-gift text-xl"></i>
                </div>
                <div className="text-left">
                  <h4 className="font-bold">BÔNUS EXCLUSIVO</h4>
                  <p>Treinamento completo sobre email marketing com ferramenta 100% gratuita!</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4 justify-center animate-fade-in-up" style={{animationDelay: '0.7s'}}>
            <div 
              className="relative" 
              onMouseEnter={() => setIsHovered(true)} 
              onMouseLeave={() => setIsHovered(false)}
            >
              <Link 
                href="#comprar-agora" 
                className="bg-secondary hover:bg-opacity-90 text-white font-bold py-4 px-6 rounded-lg inline-block text-lg transition shadow-lg btn-hover-effect" 
              >
                PLANO ESSENCIAL POR APENAS R$ 67,90
              </Link>
              {isHovered && (
                <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center animate-pulse" style={{pointerEvents: 'none'}}>
                  <div className="absolute h-full w-full bg-secondary/30 rounded-lg transform scale-110 blur-md"></div>
                </div>
              )}
            </div>
            
            <div 
              className="relative" 
              onMouseEnter={() => setIsHovered(true)} 
              onMouseLeave={() => setIsHovered(false)}
            >
              <Link 
                href="#comprar-agora" 
                className="bg-accent hover:bg-opacity-90 text-white font-bold py-4 px-6 rounded-lg inline-block text-lg transition shadow-lg btn-hover-effect relative" 
              >
                PLANO COMPLETO POR APENAS R$ 97,90
                <span className="absolute -top-3 -right-3 bg-white text-accent text-xs px-2 py-1 rounded-full font-bold animate-pulse-slow">MELHOR VALOR</span>
              </Link>
              {isHovered && (
                <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center animate-pulse" style={{pointerEvents: 'none'}}>
                  <div className="absolute h-full w-full bg-accent/30 rounded-lg transform scale-110 blur-md"></div>
                </div>
              )}
            </div>
          </div>
          
          <p className="mt-4 text-gray-200 animate-fade-in-up" style={{animationDelay: '0.9s'}}>
            Investimento único • Acesso vitalício • Garantia de 7 dias
          </p>
          
          <div className="mt-8 p-4 bg-accent bg-opacity-20 rounded-lg inline-block animate-fade-in-up transform hover:scale-105 transition-transform duration-300" style={{animationDelay: '1.1s'}}>
            <p className="font-bold text-white flex items-center">
              <i className="fas fa-lightbulb text-accent mr-2 animate-pulse-slow"></i>
              Aplique o conhecimento na prática e domine o email marketing com ferramenta 100% gratuita!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
