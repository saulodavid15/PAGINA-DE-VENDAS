import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'wouter';

const StickyNavbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Usar useCallback para evitar re-declarações a cada renderização
  const handleScroll = useCallback(() => {
    const scrollPosition = window.scrollY;
    setIsScrolled(scrollPosition > 100);
    
    // Se o menu está aberto e o usuário rola, feche o menu
    if (mobileMenuOpen && scrollPosition > 100) {
      setMobileMenuOpen(false);
    }
  }, [mobileMenuOpen]);
  
  useEffect(() => {
    // Adiciona o event listener uma única vez
    window.addEventListener('scroll', handleScroll);
    
    // Remove o event listener quando o componente for desmontado
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]); // Dependência necessária porque handleScroll pode mudar
  
  const toggleMobileMenu = useCallback(() => {
    setMobileMenuOpen(prevState => !prevState);
  }, []);
  
  const closeMenu = useCallback(() => {
    setMobileMenuOpen(false);
  }, []);
  
  // Intercepta cliques fora do menu mobile para fechá-lo
  useEffect(() => {
    if (!mobileMenuOpen) return;
    
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const isMenuClick = target.closest('.mobile-menu') !== null;
      const isToggleClick = target.closest('.menu-toggle') !== null;
      
      if (!isMenuClick && !isToggleClick) {
        setMobileMenuOpen(false);
      }
    };
    
    document.addEventListener('click', handleOutsideClick);
    return () => document.removeEventListener('click', handleOutsideClick);
  }, [mobileMenuOpen]);
  
  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'shadow-lg py-2' : 'bg-transparent py-4'}`} style={{backgroundColor: isScrolled ? '#003366' : 'transparent'}}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="text-white font-bold text-xl">
            <Link href="/">Como Vender para o Governo</Link>
          </div>
          
          {/* Menu desktop */}
          <div className="hidden md:flex space-x-6">
            <Link href="#beneficios" className="text-white hover:text-accent transition-colors">Benefícios</Link>
            <Link href="#conteudo" className="text-white hover:text-accent transition-colors">Conteúdo</Link>
            <Link href="#perguntas" className="text-white hover:text-accent transition-colors">Dúvidas</Link>
          </div>
          
          <div className="flex items-center space-x-3">
            <Link href="#comprar-agora" className="hover:bg-opacity-90 text-white px-4 py-2 rounded-lg btn-hover-effect hidden sm:block" style={{backgroundColor: '#E67E22'}}>
              Garantir Vaga
            </Link>
            
            {/* Botão hamburger para dispositivos móveis */}
            <button 
              className="md:hidden text-white focus:outline-none menu-toggle"
              onClick={toggleMobileMenu}
              aria-label="Menu de navegação"
            >
              <i className={`fas ${mobileMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
            </button>
          </div>
        </div>
      </div>
      
      {/* Menu mobile */}
      <div 
        className={`mobile-menu md:hidden bg-primary text-white shadow-lg transition-all duration-300 overflow-hidden ${mobileMenuOpen ? 'max-h-60' : 'max-h-0'}`} 
        style={{backgroundColor: '#003366'}}
        aria-hidden={!mobileMenuOpen}
      >
        <div className="container mx-auto px-4 py-2">
          <div className="flex flex-col space-y-3">
            <Link href="#beneficios" className="py-2 hover:text-accent transition-colors" onClick={closeMenu}>Benefícios</Link>
            <Link href="#conteudo" className="py-2 hover:text-accent transition-colors" onClick={closeMenu}>Conteúdo</Link>
            <Link href="#perguntas" className="py-2 hover:text-accent transition-colors" onClick={closeMenu}>Dúvidas</Link>
            <Link 
              href="#comprar-agora" 
              className="bg-accent hover:bg-opacity-90 text-white py-2 px-4 rounded-lg text-center mt-2 btn-hover-effect" 
              style={{backgroundColor: '#E67E22'}}
              onClick={closeMenu}
            >
              Garantir Minha Vaga
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default StickyNavbar;